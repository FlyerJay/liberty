<script lang="ts">
export default {
  data(): any {
    return {
      test: 123
    };
  },
  props: ['propname', 'anotherProp']
};
</script>
