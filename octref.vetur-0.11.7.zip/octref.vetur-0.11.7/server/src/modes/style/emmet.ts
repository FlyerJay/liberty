export enum Priority {
  Emmet,
  Platform
}
