# Credits

Main Developer: [@octref](https://github.com/octref)

Contributors:
- [@HerringtonDarkholme](https://github.com/HerringtonDarkholme)
- [@sandersn](https://github.com/sandersn)

### Attributions

Vetur is based on Microsoft's [html language service](https://github.com/Microsoft/vscode/tree/master/extensions/html) for VS Code.

Others:
- Logo from [vuejs/vuejs.org](https://github.com/vuejs/vuejs.org)
- Grammar based on [vuejs/vue-syntax-highlight](https://github.com/vuejs/vue-syntax-highlight)
- Sass grammar based on [robinbentley/vscode-sass-indented](https://github.com/robinbentley/vscode-sass-indented)
- PostCSS grammar based on [azat-io/atom-language-postcss](https://github.com/azat-io/atom-language-postcss)
