# Emmet

New Emmet support is available for `html`, `css`, `scss`, `less`, `stylus` without any configuration for VS Code 1.15.0+.
