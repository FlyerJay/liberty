# Roadmap

See https://github.com/vuejs/vetur/issues/188 for now.