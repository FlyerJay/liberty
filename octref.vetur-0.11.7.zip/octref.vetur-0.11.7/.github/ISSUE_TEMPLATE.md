- [ ] I have searched through existing issues
- [ ] I have read through [docs](https://vuejs.github.io/vetur)
- [ ] I have read [FAQ](https://github.com/vuejs/vetur/blob/master/docs/FAQ.md)

## Info

- Platform: <!-- Win/macOS/Linux -->
- Vetur version:
- VS Code version:

## Problem

<!-- Include error message from Panel -> Output -> Vue Language Server -->
<!-- With screenshot / gif if possible -->

## Reproducible Case

<!--
  Important. Please provide clear steps for reproducing the problem.
  Otherwise we can't help you and your issue might be closed.
  For example, fork https://github.com/octref/veturpack and modify it to reproduce the error,
  then push your changes to GitHub and send us the link.
-->
